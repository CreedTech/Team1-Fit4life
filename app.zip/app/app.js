var myModule = angular.module('myApp', ['ngRoute'])

myModule.config(['$routeProvider', function($routeProvider){
    $routeProvider
    .when('/home',{
        templateUrl:'view/home.html',
    })
    .when('/classes',{
        templateUrl:'view/classes.html',
        /*controller:'AboutController',*/
    }) 
    .when('/about',{
        templateUrl:'view/about.html',
       /* controller:'PropertiesController',*/
    }) 
    .when('/contact',{
        templateUrl:'view/contact.html',
        /*controller:'contactController',*/
    }) 
    
    .when('/blog',{
        templateUrl:'view/blog.html',
        /*controller:'duplexController',*/
    }) 
    
    
    
    
     .otherwise({
        redirectTo: '/home'
    })
      
}])

